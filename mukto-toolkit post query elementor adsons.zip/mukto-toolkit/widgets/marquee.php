<?php
/**

 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class mukto_marquee_wedget extends \Elementor\Widget_Base {


	public function get_name() {
		return 'content';
	}


	public function get_title() {
		return __( 'Mukto Marquee', 'mukto-toolkit' );
	}


	public function get_icon() {
		return 'eicon-accordion';
	}

	public function get_categories() {
		return [ 'general','mukto' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'marquee_section',
			[
				'label' => __( 'Marquee Items', 'mukto-toolkit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_query',
			[
				'label' => __( 'Post Query', 'mukto-toolkit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Post Number here', 'mukto-toolkit' ),
				'default' => 'post',
			]
		);

		$this->add_control(
			'post_number',
			[
				'label' => __( 'Post number', 'mukto-toolkit' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'placeholder' => __( 'Post Number here', 'mukto-toolkit' ),
				'default' => 4,
			]
		);

		$this->end_controls_section();
		
	}


	
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		if( $settings['marquee'] ){
			?>


<?php

$args = array(
	'posts_per_page' => $settings['post_number'],
	'post_type' => $settings['post_query'],
);

$query = new WP_Query( $args );

?>

<?php if( $query->have_posts() ) : ?>
	<div class="marque_section">
			<div class="marque_list">
				<ul>
					
				
					<div class="Notics_marquee">
						<marquee behavior="smooth" direction="up" OnMouseOver="this.stop()" 
						OnMouseOut="this.start()">
						
						<?php while ( $query->have_posts() ) : $query->the_post(); ?>
					
						<?php
							$count =1;
								 
									?>
							<li>
								<div class="Date">
									<span>
										<?php the_time('j'); ?> <br>
										<?php the_time( 'M' );?>
										<p class="year"><?php the_time('Y'); ?></p>
									</span>
								</div>
								<div class="info_link">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</div>
							</li>

							<?php $count++; ?>
							
							<?php endwhile; ?>
						</marquee>
					</div>
				</ul>
			</div>
		</div>

<?php endif; ?>

<?php wp_reset_query(); ?>


		

<?php
		}
		// end Repeater check 
	}
	

}
?>